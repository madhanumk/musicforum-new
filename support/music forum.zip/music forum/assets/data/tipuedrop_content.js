var tipuedrop = {
    "pages": [
        {
            "title": "Jenna Davis",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Influencer, PARIS</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Dan Walker",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Developer, NY</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Stella Bergmann",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Student, BERLIN</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Daniel Wellington",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Teacher, LONDON</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "David Kim",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Developer, LA</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Edward Mayers",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Doctor, DUBLIN</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Elise Walker",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Influencer, LONDON</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Milly Augustine",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Lawyer, ROME</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Bobby Brown",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Designer, PARIS</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Nelly Schwartz",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>CFO, MELBOURNE</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Lana Henrikssen",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Student, HELSINKI</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Gaelle Morris",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Merchant, Lyon</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Mike Lasalle",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Businessman, TORONTO</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Rolf Krupp",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Accountant, BERLIN</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Android Studio",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Technology</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Angular",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Technology</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Domino's Pizza",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Pizza & Fast Food</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "IMDB",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Movies / Entertainment</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Vuejs",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Technology</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Reactjs",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Technology</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "Photoshop",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Design</small>",
            "url": "/profile-main.html"
        },
        {
            "title": "WordPress",
            "thumb": "https://via.placeholder.com/150x150",
            "text": "<small>Technology</small>",
            "url": "/profile-main.html"
        }
    ]
};
